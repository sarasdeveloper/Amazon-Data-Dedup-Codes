with base as (
  SELECT
    d.client_name,
    d.fetchDate,
    CAST(d.portfolioId AS NUMERIC) AS portfolioId,
    d.name,
    d.budget,
    d.inBudget,
    d.state,
    d._daton_user_id,
    d._daton_batch_runtime,
    d._daton_batch_id
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_Portfolio` d
  INNER JOIN (
    SELECT
      fetchDate,
      portfolioId,
      MAX( _daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_Portfolio`
    GROUP BY
      1,
      2 ) mx
  ON
     d.portfolioId = mx.portfolioId
    AND d.fetchDate = mx.fetchDate
    AND d._daton_batch_runtime = mx.max_value)
SELECT base.*
FROM base 
INNER JOIN (
    SELECT
      fetchDate,
      portfolioId,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2 ) mx2
  ON
     base.portfolioId = mx2.portfolioId
    AND base.fetchDate = mx2.fetchDate
    AND base._daton_batch_id = mx2.max_value





