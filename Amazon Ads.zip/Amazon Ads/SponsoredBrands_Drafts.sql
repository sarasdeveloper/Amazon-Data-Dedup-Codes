with base as 
(
  SELECT
  d.client_name,
d.fetchDate,
d.profileId,
d.draftCampaignId,
d.name,
d.budget,
d.budgetType,
d.startDate,
d.endDate,
d.bidOptimization,
d.bidMultiplier,
cast(d.portfolioId as Numeric) portfolioId,
d.creative,
d.landingPage,
d._daton_user_id,
d._daton_batch_runtime,
d._daton_batch_id
FROM
  `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_Drafts` d
INNER JOIN (
  SELECT
    fetchDate,
    draftCampaignId,
    MAX( _daton_batch_runtime) mx
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_Drafts`
  GROUP BY
    1,
    2) mx
ON
 d.draftCampaignId = mx.draftCampaignId
  AND d.fetchDate = mx.fetchDate
  AND d._daton_batch_runtime = mx.mx
)
SELECT base.*
FROM base 
INNER JOIN (
  SELECT
    fetchDate,
    draftCampaignId,
    MAX( _daton_batch_id) max_value
  FROM
    base
  GROUP BY
    1,
    2) mx2
ON
 base.draftCampaignId = mx2.draftCampaignId
  AND base.fetchDate = mx2.fetchDate
    AND base._daton_batch_id = mx2.max_value

