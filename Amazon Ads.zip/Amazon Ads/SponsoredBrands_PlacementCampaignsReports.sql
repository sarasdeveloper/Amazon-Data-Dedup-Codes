with base as 
(
  SELECT
    d.client_name,
d.reportDate,
d.placement,
d.campaignBudget,
d.campaignBudgetType,
d.campaignStatus,
d._daton_user_id,
d._daton_batch_runtime,
d._daton_batch_id
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_PlacementCampaignsReports` d
  INNER JOIN (
    SELECT
      reportDate ,
      placement,
      campaignBudget,
      campaignStatus,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_PlacementCampaignsReports`
    GROUP BY
      1,
      2,
      3,
      4) mx
  ON
    d.placement = mx.placement
    AND d.reportDate = mx.reportDate
    AND d._daton_batch_runtime = mx.mx
    and d.campaignBudget = mx.campaignBudget
    and d.campaignStatus = mx.campaignStatus
)
SELECT base.*
FROM base 
INNER JOIN (
    SELECT
      reportDate ,
      placement,
      campaignBudget,
      campaignStatus,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2,
      3,4) mx2
  ON
    base.placement = mx2.placement
    AND base.reportDate = mx2.reportDate
    and base.campaignBudget = mx2.campaignBudget
    and base.campaignStatus = mx2.campaignStatus
    AND base._daton_batch_id = mx2.max_value

