with base as 
(
 SELECT
d.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_Campaign` d
  INNER JOIN (
    SELECT
      fetchDate ,
      campaignId ,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_Campaign`
    GROUP BY
      1,
      2) mx
  ON
    d.fetchDate = mx.fetchDate
    AND d._daton_batch_runtime = mx.mx
    and d.campaignId = mx.campaignId
   
)
SELECT base.*
FROM base 
INNER JOIN (
      SELECT
      fetchDate ,
      campaignId ,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2) mx2
  ON
    base.fetchDate = mx2.fetchDate
    and base.campaignId = mx2.campaignId
    AND base._daton_batch_id = mx2.max_value

