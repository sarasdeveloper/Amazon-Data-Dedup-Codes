with base as 
(
 SELECT
d.client_name,
d.fetchDate,
d.profileId,
d.keywordId,
d.campaignId,
d.adGroupId,
d.state,
d.keywordText,
d.matchType,
d.creationDate,
d.lastUpdatedDate,
d.servingStatus,
d._daton_user_id,
d._daton_batch_runtime,
d._daton_batch_id
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_BiddableKeywordsEx` d
  INNER JOIN (
    SELECT
      fetchDate ,
      keywordId ,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_BiddableKeywordsEx`
    GROUP BY
      1,
      2) mx
  ON
    d.fetchDate = mx.fetchDate
    AND d._daton_batch_runtime = mx.mx
    and d.keywordId = mx.keywordId
   
)
SELECT base.*
FROM base 
INNER JOIN (
      SELECT
      fetchDate ,
      keywordId ,
      MAX( _daton_batch_id) max_value
    FROM
     base 
    GROUP BY
      1,
      2) mx2
  ON
    base.fetchDate = mx2.fetchDate
    and base.keywordId = mx2.keywordId
    AND base._daton_batch_id = mx2.max_value

