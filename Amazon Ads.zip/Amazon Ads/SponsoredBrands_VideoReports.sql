with base as 
(
 SELECT
    d.client_name,
d.reportDate,
d.campaignId,
d.campaignStatus,
d.campaignBudget,
d.campaignBudgetType,
d.impressions,
d.clicks,
cast(d.cost as NUMERIC) cost,
d.attributedSales14d,
d.attributedSales14dSameSKU,
cast(d.attributedConversions14d as NUMERIC) attributedConversions14d,
cast(d.attributedConversions14dSameSKU as NUMERIC) attributedConversions14dSameSKU,
d._daton_user_id,
d._daton_batch_runtime,
d._daton_batch_id
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_VideoReports` d
  INNER JOIN (
    SELECT
      reportDate ,
      campaignId,
      campaignStatus,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_VideoReports`
    GROUP BY
      1,
      2,3) mx
  ON
    d.campaignId = mx.campaignId
    and d.campaignStatus = mx.campaignStatus
    AND d.reportDate = mx.reportDate
    AND d._daton_batch_runtime = mx.mx
   
)
SELECT base.*
FROM base 
INNER JOIN (
      SELECT
      reportDate ,
      campaignId,
      campaignStatus,
      MAX( _daton_batch_id) max_value
    FROM
      base 
    GROUP BY
      1,
      2,3) mx2
  ON
    base.campaignId = mx2.campaignId
    and base.campaignStatus = mx2.campaignStatus
    AND base.reportDate = mx2.reportDate
    AND base._daton_batch_id = mx2.max_value

