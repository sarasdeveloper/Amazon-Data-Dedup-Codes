with base as 
(
   SELECT
d.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_CampaignNegativeKeyword` d
  INNER JOIN (
    SELECT
      fetchDate ,
      keywordId ,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_CampaignNegativeKeyword`
    GROUP BY
      1,
      2) mx
  ON
    d.fetchDate = mx.fetchDate
    AND d._daton_batch_runtime = mx.mx
    and d.keywordId = mx.keywordId
   
)
SELECT base.*
FROM base 
INNER JOIN (
      SELECT
      fetchDate ,
      keywordId ,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2) mx2
  ON
    base.fetchDate = mx2.fetchDate
    and base.keywordId = mx2.keywordId
    AND base._daton_batch_id = mx2.max_value

