with base as 
(
         SELECT
d.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_PlacementCampaignsReports` d
  INNER JOIN (
    SELECT
      reportDate ,
      campaignId ,
      placement,
      campaignStatus,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_PlacementCampaignsReports`
    GROUP BY
      1,
      2
      ,3,4
      ) mx
  ON
    d.reportDate = mx.reportDate
    AND d._daton_batch_runtime = mx.mx
    and d.campaignId = mx.campaignId
    and d.placement = mx.placement
    and d.campaignStatus = mx.campaignStatus
)
SELECT base.*
FROM base 
INNER JOIN (
      SELECT
      reportDate ,
      campaignId ,
      placement,
      campaignStatus,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2
      ,3,4
      ) mx2
  ON
    base.reportDate = mx2.reportDate
    and base.campaignId = mx2.campaignId
    and base.placement = mx2.placement
    and base.campaignStatus = mx2.campaignStatus
    AND base._daton_batch_id = mx2.max_value

