with base as 
(
      SELECT
d.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_ProductTargetingReports` d
  INNER JOIN (
    SELECT
      reportDate ,
      targetId ,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_ProductTargetingReports`
    GROUP BY
      1,
      2
      ) mx
  ON
    d.targetId = mx.targetId
    AND d._daton_batch_runtime = mx.mx
    and d.reportDate = mx.reportDate
)
SELECT base.*
FROM base 
INNER JOIN (
      SELECT
      reportDate ,
      targetId ,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2
      ) mx2
  ON
    base.targetId = mx2.targetId
    and base.reportDate = mx2.reportDate
    AND base._daton_batch_id = mx2.max_value

