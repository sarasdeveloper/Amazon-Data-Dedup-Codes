with base as 
(
  SELECT
    d.client_name,
  d.reportDate,
  d.campaignName,
  d.campaignId,
  d.campaignStatus,
  d.campaignBudget,
  d.campaignBudgetType,
  CAST(d.impressions as INT64) as impressions,
  CAST(d.clicks as INT64) as clicks,
  CAST(d.cost as NUMERIC) as cost,
  CAST(d.attributedDetailPageViewsClicks14d as INT64) attributedDetailPageViewsClicks14d,
  CAST(d.attributedSales14d AS NUMERIC) AS attributedSales14d,
  CAST(d.attributedSales14dSameSKU AS NUMERIC) attributedSales14dSameSKU,
  CAST(d.attributedConversions14d AS INT64) AS attributedConversions14d,
  CAST(d.attributedConversions14dSameSKU AS INT64) AS attributedConversions14dSameSKU,
  CAST(d.attributedOrdersNewToBrand14d AS NUMERIC) AS attributedOrdersNewToBrand14d,
  CAST(d.attributedOrdersNewToBrandPercentage14d AS NUMERIC) AS attributedOrdersNewToBrandPercentage14d,
  CAST(d.attributedOrderRateNewToBrand14d AS NUMERIC) AS attributedOrderRateNewToBrand14d,
  CAST(d.attributedSalesNewToBrand14d AS NUMERIC) AS attributedSalesNewToBrand14d,
  attributedSalesNewToBrandPercentage14d,
  CAST(d.attributedUnitsOrderedNewToBrand14d AS NUMERIC) AS attributedUnitsOrderedNewToBrand14d,
  CAST(d.attributedUnitsOrderedNewToBrandPercentage14d AS NUMERIC) AS attributedUnitsOrderedNewToBrandPercentage14d,
  d.unitsSold14d,
  d.dpv14d,
  d._daton_user_id,
  d._daton_batch_runtime,
  d._daton_batch_id
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_CampaignsReports` d
  INNER JOIN (
    SELECT
      reportDate ,
      campaignId ,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_CampaignsReports`
    GROUP BY
      1,
      2
      ) mx
  ON
     d.campaignId = mx.campaignId
    AND d.reportDate = mx.reportDate
    AND d._daton_batch_runtime = mx.mx
)
SELECT base.*
FROM base 
INNER JOIN (
    SELECT
      reportDate ,
      campaignId ,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2
      ) mx2
  ON
     base.campaignId = mx2.campaignId
    AND base.reportDate = mx2.reportDate
    AND base._daton_batch_id = mx2.max_value

