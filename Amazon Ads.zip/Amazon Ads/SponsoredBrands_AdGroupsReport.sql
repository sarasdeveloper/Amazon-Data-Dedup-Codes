with base as
(
  SELECT
    d.client_name	,
	d.reportDate	,
	d.campaignId	,
	d.campaignName	,
	d.campaignBudget	,
	d.campaignBudgetType	,
	d.campaignStatus	,
	d.adGroupName	,
	d._daton_user_id	,
	d._daton_batch_runtime	,
	d._daton_batch_id	
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_AdGroupsReport` d
  INNER JOIN (
    SELECT
      reportDate ,
      campaignId ,
      adGroupName, 
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_AdGroupsReport`
    GROUP BY
      1,
      2,3
      ) mx
  ON
     d.campaignId = mx.campaignId
     and d.adGroupName	 = mx.adGroupName	
    AND d.reportDate = mx.reportDate
    AND d._daton_batch_runtime = mx.mx
)
select base.*
from base 
INNER JOIN (
    SELECT
      reportDate ,
      campaignId ,
      adGroupName, 
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2,3
      ) mx2
  ON
     base.campaignId = mx2.campaignId
     and base.adGroupName	 = mx2.adGroupName	
    AND base.reportDate = mx2.reportDate
    AND base._daton_batch_id = mx2.max_value