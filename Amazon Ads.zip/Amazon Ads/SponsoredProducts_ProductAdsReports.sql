with base as 
(
      SELECT
d.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_ProductAdsReports` d
  INNER JOIN (
    SELECT
      reportDate ,
      campaignId,
      adGroupId,
      asin ,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_ProductAdsReports`
    GROUP BY
      1,
      2,3,4
      ) mx
  ON
    d.asin = mx.asin
    AND d._daton_batch_runtime = mx.mx
    and d.reportDate = mx.reportDate
    and d.campaignId = mx.campaignId
    and d.adGroupId = mx.adGroupId
)
SELECT base.*
FROM base 
INNER JOIN (
       SELECT
      reportDate ,
      campaignId,
      adGroupId,
      asin ,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2,3,4
      ) mx2
  ON
    base.asin = mx2.asin
    and base.reportDate = mx2.reportDate
    and base.campaignId = mx2.campaignId
    and base.adGroupId = mx2.adGroupId
    AND base._daton_batch_id = mx2.max_value

