with base as 
(
   
SELECT
    d.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_TargetReport` d
  INNER JOIN (
    SELECT
      
      reportDate ,
      targetId,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_TargetReport`
    GROUP BY
      1,
      2) mx
  ON
    d.targetId = mx.targetId
    AND d.reportDate = mx.reportDate
    AND d._daton_batch_runtime = mx.mx
   
)
SELECT base.*
FROM base 
INNER JOIN (
      SELECT
      
      reportDate ,
      targetId,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2) mx2
  ON
    base.targetId = mx2.targetId
    AND base.reportDate = mx2.reportDate
    AND base._daton_batch_id = mx2.max_value

