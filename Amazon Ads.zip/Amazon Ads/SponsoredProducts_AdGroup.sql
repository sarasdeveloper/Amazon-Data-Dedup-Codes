with base as 
(
 SELECT
    d.client_name,
    d.fetchDate,
    d.profileId,
    d.adGroupId,
    d.campaignId,
    d.name	,
    d.defaultBid,	
    d.state	,
    d._daton_user_id,
    d._daton_batch_runtime,
    d._daton_batch_id
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_AdGroup` d
  INNER JOIN (
    SELECT
      fetchDate,
      adGroupId,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_AdGroup`
    GROUP BY
      1,
      2
      ) mx
  ON
	d.adGroupId = mx.adGroupId
    AND d.fetchDate = mx.fetchDate
    AND d._daton_batch_runtime = mx.mx
   
)
SELECT base.*
FROM base 
INNER JOIN (
      SELECT
      fetchDate,
      adGroupId,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2
      ) mx2
  ON
	base.adGroupId = mx2.adGroupId
    AND base.fetchDate = mx2.fetchDate
    AND base._daton_batch_id = mx2.max_value

