with base as
(
SELECT
  p.*
FROM (
  SELECT
    pr.*,
    id,
    marketplaceStringId
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_Profile` pr,
    UNNEST(accountinfo)) p
INNER JOIN (
  SELECT
    client_name,
    profileId,
    fetchDate,
    id,
    marketplaceStringId,
    MAX(_daton_batch_runtime) _daton_batch_runtime
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_Profile` p,
    UNNEST(accountinfo)
  GROUP BY
    1,
    2,
    3,
    4,
    5) test
ON
  p.profileId = test.profileId
  AND p.client_name = test.client_name
  AND p.fetchDate = test.fetchDate
  AND test.id = p.id
  AND test._daton_batch_runtime = p._daton_batch_runtime
  AND test.marketplaceStringId = p.marketplaceStringId)
  SELECT base.*
  FROM base 
  INNER JOIN (
  SELECT
    client_name,
    profileId,
    fetchDate,
    id,
    marketplaceStringId,
    MAX(_daton_batch_id) max_value
  FROM
    base
  GROUP BY
    1,
    2,
    3,
    4,
    5) mx2
ON
  base.profileId = mx2.profileId
  AND base.client_name = mx2.client_name
  AND base.fetchDate = mx2.fetchDate
  AND base.id = mx2.id
  AND base._daton_batch_id = mx2.max_value
  AND base.marketplaceStringId = mx2.marketplaceStringId