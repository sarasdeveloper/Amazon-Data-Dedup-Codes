with base as 
(
    SELECT
    d.client_name,
d.reportDate,
d.query,
d.campaignId,
d.campaignName,
d.adGroupId,
d.adGroupName,
d.campaignBudgetType,
d.campaignStatus,
d.keywordId,
d.keywordStatus,
cast(d.keywordBid as Numeric) keywordBid,
d.keywordText,
d.matchType,
d._daton_user_id,
d._daton_batch_runtime,
d._daton_batch_id
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_SearchTermKeywordsReport` d
    INNER JOIN (
    SELECT
      reportDate,
      query,
      keywordId,
      keywordStatus,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_SearchTermKeywordsReport`
    GROUP BY
      1,
      2,3,4
      ) mx
  ON
     d.query = mx.query
    AND d.reportDate = mx.reportDate
    AND d.keywordId = mx.keywordId
    AND d.keywordStatus = mx.keywordStatus
    AND d._daton_batch_runtime = mx.mx
)
SELECT base.*
FROM base 
INNER JOIN (
     SELECT
      reportDate,
      query,
      keywordId,
      keywordStatus,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2,3,4
      ) mx2
  ON
     base.query = mx2.query
    AND base.reportDate = mx2.reportDate
    AND base.keywordId = mx2.keywordId
    AND base.keywordStatus = mx2.keywordStatus
    AND base._daton_batch_id = mx2.max_value

