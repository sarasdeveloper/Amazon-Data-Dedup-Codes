with base as 
(
  SELECT
    d.client_name,
d.fetchDate,
d.profileId,
d.keywordId,
d.adGroupId,
d.campaignId,
d.keywordText,
d.matchType,
d.state,
d.bid,
d._daton_user_id,
d._daton_batch_runtime,
d._daton_batch_id
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_Keywords` d
  INNER JOIN (
    SELECT
      fetchDate,
      keywordId,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredBrands_Keywords`
    GROUP BY
      1,
      2) mx
  ON
     d.keywordId = mx.keywordId
    AND d.fetchDate = mx.fetchDate
    AND d._daton_batch_runtime = mx.mx
)
SELECT base.*
FROM base 
INNER JOIN (
   SELECT
      fetchDate,
      keywordId,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2) mx2
  ON
     base.keywordId = mx2.keywordId
    AND base.fetchDate = mx2.fetchDate
    AND base._daton_batch_id = mx2.max_value

