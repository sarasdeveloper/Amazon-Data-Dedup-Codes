with base as 
(
 SELECT
    d.client_name,
d.reportDate,
d.campaignName,
d.campaignId,
d.adGroupName,
d.adGroupId,
d.impressions,
d.clicks,
d.cost,
d.currency,
d.attributedConversions1d,
d.attributedConversions7d,
d.attributedConversions14d,
d.attributedConversions30d,
d.attributedConversions1dSameSKU,
d.attributedConversions7dSameSKU,
d.attributedConversions14dSameSKU,
d.attributedConversions30dSameSKU,
d.attributedUnitsOrdered1d,
d.attributedUnitsOrdered7d,
d.attributedUnitsOrdered14d,
d.attributedUnitsOrdered30d,
d.attributedSales1d,
d.attributedSales7d,
d.attributedSales14d,
d.attributedSales30d,
d.attributedSales1dSameSKU,
d.attributedSales7dSameSKU,
d.attributedSales14dSameSKU,
d.attributedSales30dSameSKU,
d.attributedUnitsOrdered1dSameSKU,
d.attributedUnitsOrdered7dSameSKU,
d.attributedUnitsOrdered14dSameSKU,
d.attributedUnitsOrdered30dSameSKU,
d._daton_user_id,
d._daton_batch_runtime,
d._daton_batch_id
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_AdGroupReports` d
  INNER JOIN (
    SELECT
      reportDate ,
      adGroupId ,
      MAX( _daton_batch_runtime) mx
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_SponsoredProducts_AdGroupReports`
    GROUP BY
      1,
      2) mx
  ON
    d.reportDate = mx.reportDate
    AND d._daton_batch_runtime = mx.mx
    and d. adGroupId = mx.adGroupId
   
)
SELECT base.*
FROM base 
INNER JOIN (
      SELECT
      reportDate,
      adGroupId,
      MAX( _daton_batch_id) max_value
    FROM
      base
    GROUP BY
      1,
      2
      ) mx2
  ON
	base.adGroupId = mx2.adGroupId
    AND base.reportDate = mx2.reportDate
    AND base._daton_batch_id = mx2.max_value

