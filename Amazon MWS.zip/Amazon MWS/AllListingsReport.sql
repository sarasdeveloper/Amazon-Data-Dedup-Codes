 with base as 
 (SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_AllListingsReport` og
  INNER JOIN (
    SELECT
  og.ReportstartDate,
og.ReportendDate,
 og.listing_id,
      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_AllListingsReport` og
    GROUP BY
      1,2,3
      ) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
    AND og.listing_id=max_og.listing_id
	and og.ReportstartDate = max_og.ReportstartDate
	and og.ReportendDate = max_og.ReportendDate
 )
  SELECT
    og.*
  FROM
    base og
  INNER JOIN (
    SELECT
      og.ReportstartDate,
og.ReportendDate,
 og.listing_id,
      MAX(_daton_batch_id) max_value
    FROM
      base og
    GROUP BY
      1,2,3
      ) max_og
  ON
    og._daton_batch_id = max_og.max_value
 AND og.listing_id=max_og.listing_id
	and og.ReportstartDate = max_og.ReportstartDate
	and og.ReportendDate = max_og.ReportendDate
