WITH
  base AS (
  SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_ListingQualityandSuppressedListingReport` og
  INNER JOIN (
    SELECT
      ReportstartDate,
      ReportendDate,
      sku,
      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_ListingQualityandSuppressedListingReport` og
    GROUP BY
      1,
      2,
      3 ) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
    AND og.ReportstartDate = max_og.ReportstartDate
    AND og.ReportendDate = max_og.ReportendDate
    AND og.sku = max_og.sku )
SELECT
  og.*
FROM
  base og
INNER JOIN (
  SELECT
    ReportstartDate,
    ReportendDate,
    sku,
    MAX(_daton_batch_id) max_value
  FROM
    base og
  GROUP BY
    1,
    2,
    3 ) max_og
ON
  og._daton_batch_id = max_og.max_value
  AND og.ReportstartDate = max_og.ReportstartDate
  AND og.ReportendDate = max_og.ReportendDate
  AND og.sku = max_og.sku