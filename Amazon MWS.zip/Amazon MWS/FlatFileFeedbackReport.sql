 with base as 
 (SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FlatFileFeedbackReport` og
  INNER JOIN (
    SELECT
	 order_id,
date,

      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FlatFileFeedbackReport` og
    GROUP BY
      1,2
      ) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
	and og.date = max_og.date
	and og.order_id = max_og.order_id

 )
  SELECT
    og.*
  FROM
    base og
  INNER JOIN (
    SELECT
order_id,
date,
      MAX(_daton_batch_id) max_value
    FROM
      base og
    GROUP BY
      1,2
      ) max_og
  ON
    og._daton_batch_id = max_og.max_value
	and og.date = max_og.date
	and og.order_id = max_og.order_id
 