with base as 
 (SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FBACustomerShipmentSalesReport` og
  INNER JOIN (
    SELECT
asin,
fnsku,
sku,
fulfillment_center_id,
amazon_order_id,
shipment_date,
      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FBACustomerShipmentSalesReport` og
    GROUP BY
      1,2,3,4,5,6
      ) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
and og.SKU = max_og.SKU
	and og.shipment_date = max_og.shipment_date
 and og.fulfillment_center_id = max_og.fulfillment_center_id
 and og.FNSKU = max_og.fnsku
  and og.amazon_order_id = max_og.amazon_order_id

 )
  SELECT
    og.*
  FROM
    base og
  INNER JOIN (
    SELECT
asin,
fnsku,
sku,
fulfillment_center_id,
amazon_order_id,
shipment_date,
      MAX(_daton_batch_id) max_value
    FROM
      base og
    GROUP BY
      1,2,3,4,5,6
      ) max_og
  ON
    og._daton_batch_id = max_og.max_value
and og.SKU = max_og.SKU
	and og.shipment_date = max_og.shipment_date
 and og.fulfillment_center_id = max_og.fulfillment_center_id
 and og.FNSKU = max_og.fnsku
  and og.amazon_order_id = max_og.amazon_order_id