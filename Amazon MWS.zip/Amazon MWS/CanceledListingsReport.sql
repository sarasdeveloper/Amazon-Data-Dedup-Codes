WITH
  base AS (
  SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_CanceledListingsReport` og
  INNER JOIN (
    SELECT
      og.ReportstartDate,
      og.ReportendDate,
      og.asin1,
      og.seller_sku,
      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_CanceledListingsReport` og
    GROUP BY
      1,
      2,
      3,
      4 ) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
    AND og.asin1 = max_og.asin1
    AND og.ReportendDate = max_og.ReportendDate
    AND og.seller_sku = max_og.seller_sku
    AND og.ReportstartDate = max_og.ReportstartDate )
SELECT
  og.*
FROM
  base og
INNER JOIN (
  SELECT
    og.ReportstartDate,
    og.ReportendDate,
    og.asin1,
    og.seller_sku,
    MAX(_daton_batch_id) max_value
  FROM
    base og
  GROUP BY
    1,
    2,
    3,
    4 ) max_og
ON
  og._daton_batch_id = max_og.max_value
  AND og.asin1 = max_og.asin1
  AND og.ReportendDate = max_og.ReportendDate
  AND og.seller_sku = max_og.seller_sku
  AND og.ReportstartDate = max_og.ReportstartDate