WITH
  base AS (
  SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FBAManageInventory` og
  INNER JOIN (
    SELECT
      ReportstartDate,
      ReportendDate,
      asin,
      sku,
      fnsku,
      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FBAManageInventory` og
    GROUP BY
      1,
      2,
      3,
      4,
      5 ) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
    AND og.sku = max_og.sku
    AND og.ReportstartDate = max_og.ReportstartDate
    AND og.asin = max_og.asin
    AND og.ReportendDate = max_og.ReportendDate
    and og.fnsku = max_og.fnsku)
SELECT
  og.*
FROM
  base og
INNER JOIN (
  SELECT
    ReportstartDate,
    asin,
    sku,
    ReportendDate,
    fnsku,
    MAX(_daton_batch_id) max_value
  FROM
    base og
  GROUP BY
    1,
    2,
    3,
    4,
    5 ) max_og
ON
  og._daton_batch_id = max_og.max_value
  AND og.sku = max_og.sku
  AND og.ReportstartDate = max_og.ReportstartDate
  AND og.asin = max_og.asin
  AND og.ReportendDate = max_og.ReportendDate
  and og.fnsku = max_og.fnsku