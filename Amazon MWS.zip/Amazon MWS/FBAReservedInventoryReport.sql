WITH
  base AS (
  SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FBAReservedInventoryReport` og
  INNER JOIN (
    SELECT
      fnsku,
      ReportstartDate,
      sku,
      ReportendDate,
      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FBAReservedInventoryReport` og
    GROUP BY
      1,
      2,
      3,
      4) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
    AND og.SKU = max_og.SKU
    AND og.ReportstartDate = max_og.ReportstartDate
    AND og.ReportendDate = max_og.ReportendDate
    AND og.FNSKU = max_og.fnsku )
SELECT
  og.*
FROM
  base og
INNER JOIN (
  SELECT
    sku,
    ReportendDate,
    fnsku,
    ReportstartDate,
    MAX(_daton_batch_id) max_value
  FROM
    base og
  GROUP BY
    1,
    2,
    3,
    4 ) max_og
ON
  og._daton_batch_id = max_og.max_value
  AND og.SKU = max_og.SKU
  AND og.ReportstartDate = max_og.ReportstartDate
  AND og.ReportendDate = max_og.ReportendDate
  AND og.FNSKU = max_og.fnsku