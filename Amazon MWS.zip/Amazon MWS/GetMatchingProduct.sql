SELECT
  k.*
FROM (
  SELECT
    gmp.Client_name,
    gmp.QueryStartDateTime,
    gmp.QueryEndDateTime,
    MarketplaceASIN.*,
    SalesRank.*,
    AttributeSets,
    Relationships,
    gmp._daton_user_id,
    gmp._daton_batch_runtime,
    gmp._daton_batch_id
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_GetMatchingProduct` gmp,
    UNNEST( Identifiers) Identifiers,
    UNNEST(MarketplaceASIN) MarketplaceASIN,
    UNNEST( SalesRankings) SalesRankings,
    UNNEST(SalesRank) SalesRank,
    UNNEST( AttributeSets),
    UNNEST( Relationships)) k
INNER JOIN (
  SELECT
    client_name,
    ASIN,
    ProductCategoryId,
    Rank,
    MAX(_daton_batch_runtime) _daton_batch_runtime
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_GetMatchingProduct`,
    UNNEST( Identifiers),
    UNNEST(MarketplaceASIN),
    UNNEST( SalesRankings),
    UNNEST(SalesRank)
  GROUP BY
    1,
    2,
    3,
    4) test
ON
  k.ASIN = test.ASIN
  AND k.ProductCategoryId = test.ProductCategoryId
  AND k.Rank = test.Rank
  AND k.client_name = test.client_name
  AND k._daton_batch_runtime = test._daton_batch_runtime
