WITH
  base AS (
  SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FBAStorageFeesReport` og
  INNER JOIN (
    SELECT
      asin,
      fnsku,
      fulfillment_center,
      weight,
      item_volume,
      average_quantity_on_hand,
      month_of_charge,
      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FBAStorageFeesReport` og
    GROUP BY
      1,
      2,
      3,
      4,
      5,
      6,
      7 ) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
    AND og.asin = max_og.asin
    AND og.fnsku = max_og.fnsku
    AND og.fulfillment_center = max_og.fulfillment_center
    AND og.weight = max_og.weight
    AND og.item_volume = max_og.item_volume
    AND og.average_quantity_on_hand = max_og.average_quantity_on_hand
    AND og.month_of_charge = max_og.month_of_charge )
SELECT
  og.*
FROM
  base og
INNER JOIN (
  SELECT
    asin,
    fnsku,
    fulfillment_center,
    weight,
    item_volume,
    average_quantity_on_hand,
    month_of_charge,
    MAX(_daton_batch_id) max_value
  FROM
    base og
  GROUP BY
    1,
    2,
    3,
    4,
    5,
    6,
    7 ) max_og
ON
  og._daton_batch_id = max_og.max_value
  AND og.asin = max_og.asin
  AND og.fnsku = max_og.fnsku
  AND og.fulfillment_center = max_og.fulfillment_center
  AND og.weight = max_og.weight
  AND og.item_volume = max_og.item_volume
  AND og.average_quantity_on_hand = max_og.average_quantity_on_hand
  AND og.month_of_charge = max_og.month_of_charge