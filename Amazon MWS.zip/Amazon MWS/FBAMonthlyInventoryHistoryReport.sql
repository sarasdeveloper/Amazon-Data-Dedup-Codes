WITH
  base AS (
  SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FBAMonthlyInventoryHistoryReport` og
  INNER JOIN (
    SELECT
      month,
      fnsku,
      sku,
      fulfillment_center_id,
      detailed_disposition,
      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FBAMonthlyInventoryHistoryReport` og
    GROUP BY
      1,
      2,
      3,
      4,
      5 ) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
    AND og.SKU = max_og.SKU
    AND og.month = max_og.month
    AND og.fulfillment_center_id = max_og.fulfillment_center_id
    AND og.FNSKU = max_og.fnsku
    AND og.detailed_disposition = max_og.detailed_disposition )
SELECT
  og.*
FROM
  base og
INNER JOIN (
  SELECT
    month,
    fnsku,
    sku,
    fulfillment_center_id,
    detailed_disposition,
    MAX(_daton_batch_id) max_value
  FROM
    base og
  GROUP BY
    1,
    2,
    3,
    4,
    5 ) max_og
ON
  og._daton_batch_id = max_og.max_value
  AND og.SKU = max_og.SKU
  AND og.month = max_og.month
  AND og.fulfillment_center_id = max_og.fulfillment_center_id
  AND og.FNSKU = max_og.fnsku
  AND og.detailed_disposition = max_og.detailed_disposition