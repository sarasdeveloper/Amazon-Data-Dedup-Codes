 with base as 
 (SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FlatFileReturnsReportbyReturnDate` og
  INNER JOIN (
    SELECT
	 Order_ID,
Order_date,
asin,
Merchant_SKU,

      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FlatFileReturnsReportbyReturnDate` og
    GROUP BY
      1,2,3,4
      ) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
	and og.Order_ID = max_og.Order_ID
	and og.asin = max_og.asin
  and og.Order_date = max_og.Order_date
  and og.Merchant_SKU = max_og.Merchant_SKU

 )
  SELECT
    og.*
  FROM
    base og
  INNER JOIN (
    SELECT
Order_ID,
Order_date,
asin,
Merchant_SKU,
      MAX(_daton_batch_id) max_value
    FROM
      base og
    GROUP BY
      1,2,3,4
      ) max_og
  ON
    og._daton_batch_id = max_og.max_value
	and og.Order_ID = max_og.Order_ID
	and og.asin = max_og.asin
  and og.Order_date = max_og.Order_date
  and og.Merchant_SKU = max_og.Merchant_SKU