SELECT
  og.*
FROM (
  SELECT
    l.Client_name,
    l.QueryStartDateTime,
    l.QueryEndDateTime,
    l.MarketplaceId,
    member.*,
    l._daton_user_id,
    l._daton_batch_runtime,
    l._daton_batch_id
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_ListInventorySupply` l,
    UNNEST( InventorySupplyList),
    UNNEST(member) member) og
INNER JOIN (
  SELECT
    l.Client_name,
    l.QueryEndDateTime,
    l.MarketplaceId,
    SellerSKU,
    FNSKU,
    ASIN,
    Condition,
    MAX(_daton_batch_runtime) max_value
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_ListInventorySupply` l,
    UNNEST( InventorySupplyList),
    UNNEST(member) member
  GROUP BY
    1,
    2,
    3,
    4,
    5,
    6,
    7) max_og
ON
  lis.Client_name = max_og.Client_name
  AND lis.QueryEndDateTime = max_og.QueryEndDateTime
  AND lis.MarketplaceId = max_og.MarketplaceId
  AND lis.SellerSKU = max_og.SellerSKU
  AND lis.FNSKU = max_og.FNSKU
  AND lis.ASIN = max_og.ASIN
  AND lis.Condition = max_og.Condition
  AND lis._daton_batch_runtime = max_og.max_value
  INNER JOIN (
  SELECT
    l.Client_name,
    l.QueryEndDateTime,
    l.MarketplaceId,
    SellerSKU,
    FNSKU,
    ASIN,
    Condition,
    MAX(_daton_batch_id) max_value
  FROM
    `roi-swift.amazon_consolidated.ListInventorySupply_Consolidated` l,
    UNNEST( InventorySupplyList),
    UNNEST(member) member
  GROUP BY
    1,
    2,
    3,
    4,
    5,
    6,
    7) max_og2
ON
  lis.Client_name = max_og2.Client_name
  AND lis.QueryEndDateTime = max_og2.QueryEndDateTime
  AND lis.MarketplaceId = max_og2.MarketplaceId
  AND lis.SellerSKU = max_og2.SellerSKU
  AND lis.FNSKU = max_og2.FNSKU
  AND lis.ASIN = max_og2.ASIN
  AND lis.Condition = max_og2.Condition
  AND lis._daton_batch_runtime = max_og2.max_value