 with base as 
 (SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FlatFileAllOrdersReportbyLastUpdate` og
  INNER JOIN (
    SELECT
	 amazon_order_id,
asin,
sku,
purchase_date,
sales_channel,
fulfillment_channel,
      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FlatFileAllOrdersReportbyLastUpdate` og
    GROUP BY
      1,2,3,4,5,6
      ) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
	and og.asin = max_og.asin
	and og.amazon_order_id = max_og.amazon_order_id
	and og.sku = max_og.sku
  and og.fulfillment_channel = max_og.fulfillment_channel
  and og.sales_channel = max_og.sales_channel
  and og.purchase_date=max_og.purchase_date
 )
  SELECT
    og.*
  FROM
    base og
  INNER JOIN (
    SELECT
amazon_order_id,
asin,
sku,
purchase_date,
sales_channel,
fulfillment_channel,
      MAX(_daton_batch_id) max_value
    FROM
      base og
    GROUP BY
      1,2,3,4,5,6
      ) max_og
  ON
    og._daton_batch_id = max_og.max_value
	and og.asin = max_og.asin
	and og.amazon_order_id = max_og.amazon_order_id
	and og.sku = max_og.sku
  and og.fulfillment_channel = max_og.fulfillment_channel
  and og.sales_channel = max_og.sales_channel
  and og.purchase_date=max_og.purchase_date
 