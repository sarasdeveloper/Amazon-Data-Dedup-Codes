 with base as 
 (SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FeePreviewReport` og
  INNER JOIN (
    SELECT
	  asin,
    sku,
      fnsku,
      product_group,
      item_package_weight,
      fulfilled_by,
      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FeePreviewReport` og
    GROUP BY
      1,2,3,4,5,6
      ) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
	and og.asin = max_og.asin
	and og.fnsku = max_og.fnsku
	and og.sku = max_og.sku
  and og.product_group = max_og.product_group
  and og.item_package_weight = max_og.item_package_weight
  and og.fulfilled_by = max_og.fulfilled_by
 )
  SELECT
    og.*
  FROM
    base
  INNER JOIN (
    SELECT
	  asin,
    sku,
      fnsku,
      product_group,
      item_package_weight,
      fulfilled_by,
      MAX(_daton_batch_id) max_value
    FROM
      base og
    GROUP BY
      1,2,3,4,5,6
      ) max_og
  ON
    og._daton_batch_id = max_og.max_value
	and og.asin = max_og.asin
	and og.fnsku = max_og.fnsku
	and og.sku = max_og.sku
   and og.product_group = max_og.product_group
  and og.item_package_weight = max_og.item_package_weight
  and og.fulfilled_by = max_og.fulfilled_by
