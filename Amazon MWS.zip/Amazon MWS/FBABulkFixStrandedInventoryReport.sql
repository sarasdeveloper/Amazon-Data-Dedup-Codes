WITH
  base AS (
  SELECT
    og.*
  FROM
    `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FBABulkFixStrandedInventoryReport` og
  INNER JOIN (
    SELECT
      ReportstartDate,
      ReportendDate,
      sku,
      product_id,
      MAX(_daton_batch_runtime) max_value
    FROM
      `{{project_name}}.{{dataset_name}}.{{Integration_Name}}_FBABulkFixStrandedInventoryReport` og
    GROUP BY
      1,
      2,
      3,
      4) max_og
  ON
    og._daton_batch_runtime = max_og.max_value
    AND og.sku = max_og.sku
    AND og.ReportstartDate = max_og.ReportstartDate
    AND og.ReportendDate = max_og.ReportendDate
    AND og.product_id = max_og.product_id)
SELECT
  og.*
FROM
  base og
INNER JOIN (
  SELECT
    ReportstartDate,
    ReportendDate,
    sku,
    product_id,
    MAX(_daton_batch_id) max_value
  FROM
    base og
  GROUP BY
    1,
    2,
    3,
    4 ) max_og
ON
  og._daton_batch_id = max_og.max_value
  AND og.sku = max_og.sku
  AND og.ReportstartDate = max_og.ReportstartDate
  AND og.ReportendDate = max_og.ReportendDate
  AND og.product_id = max_og.product_id